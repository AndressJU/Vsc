﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace di.tema3_ejemplo
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
