# Contributing

## Guidelines

- Priorizar arquitecturas limpias, modernas y escalables.
- Usar MVVM en aplicaciones WPF y mantener la lógica de negocio fuera del code-behind.
- Aplicar inyección de dependencias con `Microsoft.Extensions.DependencyInjection`.
- Usar `CommunityToolkit.Mvvm` para observables y comandos cuando sea apropiado.
- Encapsular el acceso a datos y APIs en servicios; los ViewModels deben orquestar la vista.
- Preferir C# moderno y las versiones actuales de .NET compatibles con el proyecto.
- Mantener el código fuertemente tipado, asíncrono y preparado para producción.
