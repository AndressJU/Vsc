﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace di.proyecto.clase._2026.Vista.Dialogos
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        public Login()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {

            if(string.IsNullOrEmpty(txtUsername.Text)  
                || string.IsNullOrEmpty(passClaveAcceso.Password))
                    {
                
                MessageBox.Show("Por favor, ingrese un nombre de usuario y una contraseña.",

                   "Error de inicio de sesion", MessageBoxButton.OK, MessageBoxImage.Error);
                }

            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}
