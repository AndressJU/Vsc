﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace di.tema3.hamburguer
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
