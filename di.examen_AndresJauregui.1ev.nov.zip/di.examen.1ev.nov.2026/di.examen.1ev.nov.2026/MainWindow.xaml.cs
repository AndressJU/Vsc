﻿using di.examen._1ev.nov._2026.Vista.Dialogos;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace di.examen._1ev.nov._2026
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly Func<Login> _loginFactory;

        public MainWindow(Func<Login> loginFactory)
        {
            InitializeComponent();
            _loginFactory = loginFactory;
        }

        private void btnCerrarSesion_Click(object sender, RoutedEventArgs e)
        {
            Login login = _loginFactory();
            Application.Current.MainWindow = login;
            login.Show();
            this.Close();
        }
    }
}