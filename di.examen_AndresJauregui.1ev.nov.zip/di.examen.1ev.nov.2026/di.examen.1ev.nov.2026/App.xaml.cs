﻿using di.examen._1ev.nov._2026.Vista.Dialogos;
using Microsoft.Extensions.DependencyInjection;
using System.Configuration;
using System.Data;
using System.Windows;

namespace di.examen._1ev.nov._2026
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        // Defino el contenedor de servicios como un campo privado readonly
        private readonly IServiceProvider _serviceProvider;
        public App()
        {
            ServiceCollection services = new ServiceCollection();
            ConfigureServices(services);
            _serviceProvider = services.BuildServiceProvider();
        }

        private static void ConfigureServices(IServiceCollection services)
        {
            // 1. Registrar las ventanas (IMPORTANTE: sin esto falla al ejecutar)
            services.AddTransient<Login>();
            services.AddTransient<MainWindow>();

            // 2. Registrar las factorías (para poder ir y volver entre Login y MainWindow)
            services.AddTransient<Func<Login>>(sp => () => sp.GetRequiredService<Login>());
            services.AddTransient<Func<MainWindow>>(sp => () => sp.GetRequiredService<MainWindow>());
        }

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // Arranca mostrando primero el Login
            Login login = _serviceProvider.GetRequiredService<Login>();
            MainWindow = login;
            ShutdownMode = ShutdownMode.OnMainWindowClose;
            login.Show();
        }

        protected override void OnExit(ExitEventArgs e)
        {
            base.OnExit(e);
            if (_serviceProvider is IDisposable disposable)
                disposable.Dispose();
        }
    }
}


