﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace di.examen._1ev.nov._2026.Vista.Dialogos
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        private readonly Func<MainWindow> _mainWindowFactory;
        public Login(Func<MainWindow> mainWindowFactory)
        {
            InitializeComponent();
            _mainWindowFactory = mainWindowFactory;
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtUsername.Text) || string.IsNullOrWhiteSpace(passClaveAcceso.Password))
            {
                MessageBox.Show("Por favor, ingrese un nombre de usuario y una contraseña.",
                                "Error de inicio de sesión",
                                MessageBoxButton.OK,
                                MessageBoxImage.Warning);
                return;
            }

            MainWindow mainWindow = _mainWindowFactory();
            Application.Current.MainWindow = mainWindow;
            mainWindow.Show();
            this.Close();
        }
    }
}
