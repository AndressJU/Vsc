﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace D.I.tema3_ejercicio4
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
