﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace di.ejercicio8
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
