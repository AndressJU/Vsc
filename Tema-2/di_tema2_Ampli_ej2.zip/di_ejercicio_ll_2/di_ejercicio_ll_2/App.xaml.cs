﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace di_ejercicio_ll_2
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
